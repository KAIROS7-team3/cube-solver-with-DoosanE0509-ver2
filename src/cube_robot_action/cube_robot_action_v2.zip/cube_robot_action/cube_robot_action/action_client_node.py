import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.action.client import ClientGoalHandle
from cube_interfaces.action import CubeMove
from dsr_msgs2.srv import MoveStop
import threading
import sys
import signal


class CubeMoveActionClient(Node):
    def __init__(self):
        super().__init__('cube_move_action_client')

        self._action_client = ActionClient(
            self, CubeMove, 'cube_move'
        )

        # ── MoveStop 서비스 클라이언트 ──
        self.stop_cli = self.create_client(
            MoveStop, '/motion/move_stop'
        )

        self._current_goal_handle: ClientGoalHandle = None
        self._is_running = False

        # ── Ctrl+C 시그널 핸들러 등록 ──
        signal.signal(signal.SIGINT, self._sigint_handler)

        self.get_logger().info('✅ CubeMoveActionClient 초기화 완료')

    # ─────────────────────────────────────────
    # Ctrl+C 핸들러
    # ─────────────────────────────────────────
    def _sigint_handler(self, sig, frame):
        print('\n')
        self.get_logger().warn('🚨 긴급 정지 요청 (Ctrl+C)')
        self._emergency_stop()
        rclpy.shutdown()
        sys.exit(0)

    # ─────────────────────────────────────────
    # 긴급 정지 함수
    # ─────────────────────────────────────────
    def _emergency_stop(self):
        # 1) 로봇 즉시 정지 (move_stop)
        self.get_logger().warn('🛑 로봇 즉시 정지 명령 전송')
        if self.stop_cli.service_is_ready():
            req = MoveStop.Request()
            req.stop_mode = 1  # 1 = 즉시 정지
            self.stop_cli.call_async(req)
            self.get_logger().warn('✅ move_stop 전송 완료')
        else:
            self.get_logger().error(
                '❌ /motion/move_stop 서비스 없음 — '
                '티치 펜던트 비상 정지 버튼을 누르세요!'
            )

        # 2) Action Cancel 전송
        if self._current_goal_handle is not None and self._is_running:
            self.get_logger().warn('🛑 Action Cancel 전송 중...')
            cancel_future = self._current_goal_handle.cancel_goal_async()
            cancel_future.add_done_callback(self._cancel_done_cb)

        self._is_running = False

    def _cancel_done_cb(self, future):
        result = future.result()
        if result:
            self.get_logger().warn('✅ Action 취소 완료')
        else:
            self.get_logger().error('❌ Action 취소 실패')

    # ─────────────────────────────────────────
    # Goal 전송
    # ─────────────────────────────────────────
    def send_goal(self, move_token: str):
        self.get_logger().info('서버 대기 중...')
        if not self._action_client.wait_for_server(timeout_sec=5.0):
            self.get_logger().error('❌ Action 서버 없음')
            self._prompt_next()
            return

        goal = CubeMove.Goal()
        goal.move_token = move_token
        self.get_logger().info(f'📤 Goal 전송: {move_token}')
        self.get_logger().warn(
            '🚨 긴급 정지 방법:\n'
            '   1) Ctrl+C       → 즉시 정지\n'
            '   2) stop 입력    → 즉시 정지\n'
            '   3) 티치 펜던트  → 비상 정지 버튼'
        )

        self._is_running = True
        self._send_goal_future = self._action_client.send_goal_async(
            goal,
            feedback_callback=self.feedback_cb
        )
        self._send_goal_future.add_done_callback(self.goal_response_cb)

    # ─────────────────────────────────────────
    # Goal 수락 콜백
    # ─────────────────────────────────────────
    def goal_response_cb(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn('❌ Goal 거부됨')
            self._is_running = False
            self._prompt_next()
            return

        self._current_goal_handle = goal_handle
        self.get_logger().info('✅ Goal 수락됨 — 실행 중...')

        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.result_cb)

    # ─────────────────────────────────────────
    # 피드백 콜백
    # ─────────────────────────────────────────
    def feedback_cb(self, feedback_msg):
        fb = feedback_msg.feedback
        self.get_logger().info(
            f'  📊 [{fb.steps_done}/{fb.steps_total}] {fb.current_step}'
        )

    # ─────────────────────────────────────────
    # 결과 콜백
    # ─────────────────────────────────────────
    def result_cb(self, future):
        self._is_running = False
        self._current_goal_handle = None

        from action_msgs.msg import GoalStatus
        status = future.result().status
        result = future.result().result

        if status == GoalStatus.STATUS_CANCELED:
            self.get_logger().warn('🛑 동작이 취소됐어요')
        elif result.success:
            self.get_logger().info(
                f'🎉 완료: {result.message} '
                f'({result.steps_executed}스텝)'
            )
        else:
            self.get_logger().error(f'❌ 실패: {result.message}')

        self._prompt_next()

    # ─────────────────────────────────────────
    # 사용자 입력
    # ─────────────────────────────────────────
    def _prompt_next(self):
        print('\n' + '='*40)
        print('사용 가능한 동작:')
        print('  F  F\'  F2  |  B  B\'  B2')
        print('  U  U\'  U2  |  D  D\'  D2')
        print('  R  R\'  R2  |  L  L\'  L2')
        print('  P  (Perception)')
        print('  stop : 긴급 정지')
        print('  quit : 종료')
        print('='*40)

        cmd = input('동작 입력 >> ').strip()

        if cmd == 'quit':
            self.get_logger().info('종료')
            rclpy.shutdown()
        elif cmd == 'stop':
            self._emergency_stop()
            self._prompt_next()
        else:
            self.send_goal(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = CubeMoveActionClient()

    def input_thread():
        node._prompt_next()

    thread = threading.Thread(target=input_thread, daemon=True)
    thread.start()

    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()